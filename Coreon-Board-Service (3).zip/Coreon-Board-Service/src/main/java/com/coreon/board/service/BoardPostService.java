package com.coreon.board.service;

import com.coreon.board.domain.BoardAttachment;
import com.coreon.board.domain.BoardPost;
import com.coreon.board.mapper.BoardAttachmentMapper;
import com.coreon.board.mapper.BoardPostMapper;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.server.ResponseStatusException;
import com.coreon.board.dto.response.BoardPostListItemResponse;
import com.coreon.board.dto.response.PageRes; // 너 프로젝트 경로에 맞게
import com.coreon.board.dto.response.PostDetailRes;


@Service
public class BoardPostService {

    private final BoardPostMapper boardPostMapper;
    private final BoardAttachmentMapper boardAttachmentMapper;
    private final S3service storageService;


    public BoardPostService(BoardPostMapper boardPostMapper,
                            BoardAttachmentMapper boardAttachmentMapper,
                            S3service storageService) {
        this.boardPostMapper = boardPostMapper;
        this.boardAttachmentMapper = boardAttachmentMapper;
        this.storageService = storageService;
    }

    @Transactional
    public Long createPost(com.coreon.board.dto.request.CreatePostReq req,
                           List<MultipartFile> files,
                           Long employeeNo, String username, String myDept) {

        BoardPost post = new BoardPost();
        post.setCategory(req.getCategory());
        post.setTitle(req.getTitle());
        post.setContent(req.getContent());

        // dept는 req가 비면 세션 dept 사용
        String dept = (req.getDept() == null || req.getDept().isBlank()) ? myDept : req.getDept();
        post.setDept(dept);

        post.setAuthorEmployeeNo(employeeNo);
        post.setAuthorName(username);

        boardPostMapper.insertPost(post);

        if (files != null) {
            for (MultipartFile f : files) {
                if (f == null || f.isEmpty()) continue;

                String storedUrl = storageService.upload(post.getBoardId(), f);

                BoardAttachment att = new BoardAttachment();
                att.setBoardId(post.getBoardId());
                att.setOriginalName(f.getOriginalFilename());
                att.setStoredUrl(storedUrl);
                att.setContentType(f.getContentType());
                att.setSizeBytes(f.getSize());

                boardAttachmentMapper.insertAttachment(att);
            }
        }

        return post.getBoardId();
    }

    
    
    @Transactional
    public void deletePost(Long boardId, Long requesterEmployeeNo, boolean isAdmin) {
        Long authorEmployeeNo = boardPostMapper.selectAuthorEmployeeNo(boardId);
        if (authorEmployeeNo == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "게시글이 존재하지 않습니다.");
        }

        boolean isOwner = authorEmployeeNo.equals(requesterEmployeeNo);
        if (!isOwner && !isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "삭제 권한이 없습니다.");
        }

        // 첨부 DB 먼저 삭제 (S3는 스킵)
        boardAttachmentMapper.deleteByBoardId(boardId);

        // 게시글 삭제
        //boardPostMapper.deletePostById(boardId);
        int deleted = boardPostMapper.deletePostById(boardId);
        if (deleted == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "게시글이 존재하지 않습니다.");
        }
    }
    
    @Transactional
    public void updatePost(Long boardId, com.coreon.board.dto.request.UpdatePostReq req,
    		Long requesterEmployeeNo, boolean isAdmin) {
    	
        Long authorEmployeeNo = boardPostMapper.selectAuthorEmployeeNo(boardId);
        if (authorEmployeeNo == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "게시글이 존재하지 않습니다.");
        }

        boolean isOwner = authorEmployeeNo.equals(requesterEmployeeNo);
        if (!isOwner && !isAdmin) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "수정 권한이 없습니다.");
        }

        BoardPost post = new BoardPost();
        post.setBoardId(boardId);          // path 값으로 강제
        post.setCategory(req.getCategory());
        post.setTitle(req.getTitle());
        post.setContent(req.getContent());
        post.setDept(req.getDept());

        int updated = boardPostMapper.updatePost(post);  // ✅ domain으로 업데이트
        if (updated == 0) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "게시글이 존재하지 않습니다.");
        }

    }
    
    @Transactional(readOnly = true)
    public PageRes<BoardPostListItemResponse> getPosts(
            int page, int size,
            String category, String dept,
            Long authorEmployeeNo,
            String q, String sort
    ) {
        int safePage = Math.max(page, 0);
        int safeSize = Math.min(Math.max(size, 1), 100);
        int offset = safePage * safeSize;

        var list = boardPostMapper.selectPosts(offset, safeSize, category, dept, authorEmployeeNo, q, sort);
        long total = boardPostMapper.countPosts(category, dept, authorEmployeeNo, q);

        
        return new PageRes<>(list, safePage, safeSize, total);

    }
    @Transactional(readOnly = true)
    public PostDetailRes getPostDetail(Long boardId) {
    	boardPostMapper.incrementViewCount(boardId);
    	 
        BoardPost post = boardPostMapper.selectPostById(boardId);
        if (post == null) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "게시글 없음");

        PostDetailRes res = new PostDetailRes();
        res.setBoardId(post.getBoardId());
        res.setCategory(post.getCategory());
        res.setTitle(post.getTitle());
        res.setContent(post.getContent());
        res.setDept(post.getDept());
        res.setAuthorEmployeeNo(post.getAuthorEmployeeNo());
        res.setAuthorName(post.getAuthorName());
        res.setViewCount(post.getViewCount());  
        res.setCreatedAt(post.getCreatedAt());
        res.setUpdatedAt(post.getUpdatedAt());
       
        return res;
    }


}
