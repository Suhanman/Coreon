package com.coreon.board.service;

import com.coreon.board.domain.BoardAttachment;
import com.coreon.board.domain.BoardPost;
import com.coreon.board.dto.response.AttachmentItemRes;
import com.coreon.board.mapper.BoardAttachmentMapper;
import com.coreon.board.mapper.BoardPostMapper;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.util.ArrayList;
import java.util.List;

@Service
public class BoardAttachmentService {

    private final BoardAttachmentMapper attachmentMapper;
    private final BoardPostMapper postMapper;
    private final S3service s3service;

    public BoardAttachmentService(BoardAttachmentMapper attachmentMapper,
                                  BoardPostMapper postMapper,
                                  S3service s3service) {
        this.attachmentMapper = attachmentMapper;
        this.postMapper = postMapper;
        this.s3service = s3service;
    }

    @Transactional(readOnly = true)
    public List<AttachmentItemRes> list(Long boardId) {
        return attachmentMapper.selectByBoardId(boardId).stream()
                .map(a -> new AttachmentItemRes(
                        a.getAttachmentId(), a.getBoardId(), a.getOriginalName(),
                        a.getStoredUrl(), a.getContentType(), a.getSizeBytes(), a.getCreatedAt()
                ))
                .toList();
    }

    @Transactional
    public List<Long> addAttachments(Long boardId, List<MultipartFile> files) {
        if (files == null || files.isEmpty()) return List.of();

        // 게시글 존재 체크 (없으면 예외)
        BoardPost post = postMapper.selectPostById(boardId);
        if (post == null) throw new IllegalArgumentException("게시글 없음: " + boardId);

        List<Long> ids = new ArrayList<>();

        for (MultipartFile f : files) {
            // 1) S3 업로드
        	String url = s3service.upload(boardId, f); // S3service 메서드명에 맞춰 변경

            // 2) DB insert
            BoardAttachment att = new BoardAttachment();
            att.setBoardId(boardId);
            att.setOriginalName(f.getOriginalFilename());
            att.setStoredUrl(url);
            att.setContentType(f.getContentType());
            att.setSizeBytes(f.getSize());

            attachmentMapper.insertAttachment(att);
            ids.add(att.getAttachmentId());
        }

        return ids;
    }

    @Transactional
    public void deleteAttachment(Long attachmentId, Long loginEmployeeNo, boolean isAdmin) {
        BoardAttachment att = attachmentMapper.selectById(attachmentId);
        if (att == null) throw new IllegalArgumentException("첨부 없음: " + attachmentId);

        BoardPost post = postMapper.selectPostById(att.getBoardId());
        if (post == null) throw new IllegalArgumentException("게시글 없음: " + att.getBoardId());

        // 작성자 체크 
        Long authorEmployeeNo = post.getAuthorEmployeeNo(); 
        if (!isAdmin && !loginEmployeeNo.equals(authorEmployeeNo)) {
            throw new SecurityException("삭제 권한 없음");
        }

        // S3 삭제(선택) - storedUrl로 키를 추출하는 로직 필요
        // s3service.deleteByUrl(att.getStoredUrl());

        attachmentMapper.deleteById(attachmentId);
    }
}
