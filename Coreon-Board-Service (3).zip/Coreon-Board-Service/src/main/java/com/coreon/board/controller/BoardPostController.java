package com.coreon.board.controller;

import com.coreon.board.dto.request.CreatePostReq;
import com.coreon.board.dto.request.UpdatePostReq;
import com.coreon.board.dto.response.CreatePostRes;
import com.coreon.board.dto.response.UpdatePostRes;
import com.coreon.board.service.BoardPostService;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/board")
public class BoardPostController {

    private final BoardPostService boardPostService;

    public BoardPostController(BoardPostService boardPostService) {
        this.boardPostService = boardPostService;
    }

    @GetMapping("/posts")
    public ResponseEntity<?> list(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size,
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String dept,
            @RequestParam(required = false) Long authorEmployeeNo,
            @RequestParam(required = false) String q,
            @RequestParam(defaultValue = "latest") String sort,
            HttpSession session
    ) {
        requireLogin(session);

        return ResponseEntity.ok(
                boardPostService.getPosts(page, size, category, dept, authorEmployeeNo, q, sort)
        );
    }

    // ✅ 게시글 작성 + 첨부 포함 (multipart)
    @PostMapping(value = "/posts", consumes = "multipart/form-data")
    public ResponseEntity<CreatePostRes> createPost(
            @ModelAttribute CreatePostReq req,
            @RequestPart(name = "files", required = false) List<MultipartFile> files,
            HttpSession session
    ) {
        Long employeeNo = requireEmployeeNo(session);
        String username = (String) session.getAttribute("username");
        String myDept = (String) session.getAttribute("dept");

        Long boardId = boardPostService.createPost(req, files, employeeNo, username, myDept);

        return ResponseEntity.status(201).body(new CreatePostRes("작성 완료", boardId));
    }

    // ✅ 게시글 상세
    @GetMapping("/posts/{boardId}")
    public ResponseEntity<?> detail(@PathVariable Long boardId, HttpSession session) {
        requireLogin(session);
        return ResponseEntity.ok(boardPostService.getPostDetail(boardId));
    }

    // ✅ 게시글 수정
    @PutMapping("/posts/{boardId}")
    public ResponseEntity<UpdatePostRes> updatePost(
            @PathVariable Long boardId,
            @RequestBody UpdatePostReq req,
            HttpSession session
    ) {
        Long employeeNo = requireEmployeeNo(session);
        boolean isAdmin = isAdmin(session);

        boardPostService.updatePost(boardId, req, employeeNo, isAdmin);

        return ResponseEntity.ok(new UpdatePostRes("수정 완료", boardId));
    }

    // ✅ 게시글 삭제: 작성자 or 관리자만
    @DeleteMapping("/posts/{boardId}")
    public ResponseEntity<Void> deletePost(@PathVariable Long boardId, HttpSession session) {
        Long employeeNo = requireEmployeeNo(session);
        boolean isAdmin = isAdmin(session);

        boardPostService.deletePost(boardId, employeeNo, isAdmin);
        return ResponseEntity.noContent().build(); // 204
    }

    // ---------------------------
    // Session Helpers (최소 공통화)
    // ---------------------------
    private void requireLogin(HttpSession session) {
        if (session.getAttribute("employeeNo") == null) {
            throw new UnauthorizedException("로그인 필요");
        }
    }

    private Long requireEmployeeNo(HttpSession session) {
        Object v = session.getAttribute("employeeNo");
        if (v == null) throw new UnauthorizedException("로그인 필요");
        return (Long) v;
    }

    private boolean isAdmin(HttpSession session) {
        Boolean isAdminAttr = (Boolean) session.getAttribute("isAdmin");
        String role = (String) session.getAttribute("role");
        return (isAdminAttr != null && isAdminAttr)
                || (role != null && (role.equalsIgnoreCase("ADMIN") || role.equalsIgnoreCase("ROLE_ADMIN")));
    }

    // ---------------------------
    // Minimal Exception (Controller 레벨)
    // ---------------------------
    @ResponseStatus(org.springframework.http.HttpStatus.UNAUTHORIZED)
    private static class UnauthorizedException extends RuntimeException {
        public UnauthorizedException(String message) {
            super(message);
        }
    }
}
